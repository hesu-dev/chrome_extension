(function () {
  window.Roll20CleanerFeatureFlags = window.Roll20CleanerFeatureFlags || {
    enableJsonDownload: true,
  };
})();
